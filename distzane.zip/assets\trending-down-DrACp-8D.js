import{e as n}from"./index-CpKi0QSz.js";const e=[["path",{d:"M16 17h6v-6",key:"t6n2it"}],["path",{d:"m22 17-8.5-8.5-5 5L2 7",key:"x473p"}]],t=n("trending-down",e);export{t as T};
